#!/bin/bash

g++ -o zadanie ./src/*.cpp -I./inc/ -std=c++20
./zadanie
