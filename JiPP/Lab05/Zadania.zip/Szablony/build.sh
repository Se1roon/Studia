#!/bin/bash

g++ -o zadanie ./src/Main.cpp -I./inc/ -std=c++20 -Wall -Wextra
./zadanie
